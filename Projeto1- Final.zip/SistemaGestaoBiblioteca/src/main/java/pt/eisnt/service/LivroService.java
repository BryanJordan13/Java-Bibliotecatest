package pt.eisnt.service;

import pt.eisnt.model.Autor;
import pt.eisnt.model.Livro;

import java.util.ArrayList;
import java.util.List;


// Criação da lista da classe do model
public class LivroService {
    private List<Livro> listaLivros = new ArrayList<>();
    private AutorService autorService;

    // LivroService vai ter que passar pelo AutorService para que ele funcione
    public LivroService(AutorService autorService){
        this.autorService = autorService;

        // 🔽 DADOS INICIAIS
        adicionarLivro(new Livro("9789722327314", "Os Maias", "Porto Editora", autorService.buscarAutor("1"), true));
        adicionarLivro(new Livro("9789896441868", "Ensaio sobre a Cegueira", "Caminho", autorService.buscarAutor("2"), true));
        adicionarLivro(new Livro("9789896605581", "O Alquimista", "Pergaminho", autorService.buscarAutor("3"), true));
        adicionarLivro(new Livro("9789722523112", "Aparição", "Asa", autorService.buscarAutor("4"), true));
        adicionarLivro(new Livro("9789723829497", "Os Lusíadas", "Porto Editora", autorService.buscarAutor("5"), true));
        adicionarLivro(new Livro("9789897731012", "A Sombra do Vento", "Planeta", autorService.buscarAutor("6"), true));
        adicionarLivro(new Livro("9780451524935", "1984", "Signet", autorService.buscarAutor("7"), true));
        adicionarLivro(new Livro("9780747532743", "Harry Potter", "Bloomsbury", autorService.buscarAutor("8"), true));
        adicionarLivro(new Livro("9780307474278", "O Código Da Vinci", "Doubleday", autorService.buscarAutor("9"), true));
        adicionarLivro(new Livro("9780099448761", "Kafka à Beira-Mar", "Vintage", autorService.buscarAutor("10"), true));
        adicionarLivro(new Livro("9780141439518", "Orgulho e Preconceito", "Penguin", autorService.buscarAutor("11"), true));
        adicionarLivro(new Livro("9780486280615", "Tom Sawyer", "Dover", autorService.buscarAutor("12"), true));
        adicionarLivro(new Livro("9780140449136", "Crime e Castigo", "Penguin", autorService.buscarAutor("13"), true));
        adicionarLivro(new Livro("9780684801223", "O Velho e o Mar", "Scribner", autorService.buscarAutor("14"), true));
        adicionarLivro(new Livro("9780618640157", "O Senhor dos Anéis", "Houghton", autorService.buscarAutor("15"), true));
        adicionarLivro(new Livro("9780307743657", "It", "Viking", autorService.buscarAutor("16"), true));
        adicionarLivro(new Livro("9780007119356", "Assassinato no Expresso do Oriente", "HarperCollins", autorService.buscarAutor("17"), true));
        adicionarLivro(new Livro("9780140444308", "Os Miseráveis", "Penguin", autorService.buscarAutor("18"), true));
        adicionarLivro(new Livro("9780199232765", "Guerra e Paz", "Oxford", autorService.buscarAutor("19"), true));
        adicionarLivro(new Livro("9780805209990", "A Metamorfose", "Schocken", autorService.buscarAutor("20"), true));
    }



    //Metodos de Gestão e Pesquisa
    public Livro buscarLivroIsbn(String isbn){
        for(Livro l: listaLivros){
            if(l.getIsbn().equals(isbn)) {
                return l;
            }
        }
        return null;
    }

    public void adicionarLivro(Livro novolivro){
        //Consulta se o Isbn já existe, se sim da mensagem de erro e não prossegue
        if(buscarLivroIsbn(novolivro.getIsbn()) != null){
            throw new IllegalStateException("Erro: ISBN já registado para outro Livro.");
        }
        //Consulta se o Autor já existe na lista de Autores, caso não exista informa ao utilizador que ele primeiro precisa adicionar o Autor
        if(this.autorService.buscarAutor(novolivro.getAutor().getId()) == null) {
            throw new IllegalStateException("Erro, O Autor deste livro não está rgistado no sistema. Faça o registo do Autor primeiro.");
        }
        //Se tudo nada der IllegalState adiciona o livro na lista
        this.listaLivros.add(novolivro);
        System.out.println("Livro " + novolivro.getTitulo() + " adicionado com sucesso.");

    }

    public void editarLivro(String isbn, String novoTitulo, String novoeditora, String idNovoAutor){
        Livro livro = buscarLivroIsbn(isbn);
        if (livro == null) {
            throw new IllegalArgumentException("Livro com ISBN não encontrado.");
        }
        if (!novoTitulo.isBlank()) livro.setTitulo(novoTitulo);
        if (!novoeditora.isBlank()) livro.setEditora(novoeditora);
        if(!idNovoAutor.isBlank()) {
            Autor novoAutor = autorService.buscarAutor(idNovoAutor);
            if (novoAutor != null){
                livro.setAutor(novoAutor);
            }
            else {
                throw new IllegalArgumentException("novo autor não encontrado. Cancelando edição.");
            }
        }
        System.out.println("Livro atualizado com sucesso.");
    }

    public void listarLivros() {
        if (listaLivros.isEmpty()) {
            System.out.println("O acervo está vazio");
        }
        else {
            for (Livro l: listaLivros) {
                String status = l.isDisponivel() ? "[Disponivel] " : "[Emprestado] ";

                System.out.println(status + "ISBN: " + l.getIsbn() + " | Titulo: " + l.getTitulo() + " | Editora: " +l.getEditora() + " | Autor: " + l.getAutor().getNome());
            }
        }
    }




}