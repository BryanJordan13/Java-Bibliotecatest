package pt.eisnt.service;

import pt.eisnt.model.Leitor;
import java.util.ArrayList;
import java.util.List;

// Criação da lista da classe do model
public class LeitorService {
    private List<Leitor> listaLeitores = new ArrayList<>();
    private int proximoId = 1;//Contador para criar Ids sequenciais

    // 🔽 CONSTRUTOR COM DADOS INICIAIS
    public LeitorService() {
        adicionarLeitor("João Silva", "joao@gmail.com", "912345678");
        adicionarLeitor("Maria Costa", "maria@gmail.com", "913456789");
        adicionarLeitor("Pedro Santos", "pedro@gmail.com", "914567890");
        adicionarLeitor("Ana Ferreira", "ana@gmail.com", "915678901");
        adicionarLeitor("Tiago Martins", "tiago@gmail.com", "916789012");
        adicionarLeitor("Rita Alves", "rita@gmail.com", "917890123");
        adicionarLeitor("Carlos Pinto", "carlos@gmail.com", "918901234");
        adicionarLeitor("Sofia Rocha", "sofia@gmail.com", "919012345");
        adicionarLeitor("Bruno Gomes", "bruno@gmail.com", "910123456");
        adicionarLeitor("Inês Lopes", "ines@gmail.com", "911234567");
        adicionarLeitor("Miguel Sousa", "miguel@gmail.com", "922345678");
        adicionarLeitor("Carla Mendes", "carla@gmail.com", "923456789");
        adicionarLeitor("André Costa", "andre@gmail.com", "924567890");
        adicionarLeitor("Beatriz Ramos", "beatriz@gmail.com", "925678901");
        adicionarLeitor("Ricardo Nunes", "ricardo@gmail.com", "926789012");
        adicionarLeitor("Patrícia Dias", "patricia@gmail.com", "927890123");
        adicionarLeitor("Fábio Teixeira", "fabio@gmail.com", "928901234");
        adicionarLeitor("Daniela Correia", "daniela@gmail.com", "929012345");
        adicionarLeitor("Hugo Cardoso", "hugo@gmail.com", "930123456");
        adicionarLeitor("Mariana Duarte", "mariana@gmail.com", "931234567");
    }


    //Metodo de busca
    public Leitor buscarLeitor(String id){
        for(Leitor l: listaLeitores){
            if(l.getId().equals(id)) {
                return l;
            }
        }
        return null;
    }

    //Metodo adicionar Leitor
    public void adicionarLeitor(String nome, String email, String telemovel){

        String idGerado = String.valueOf(proximoId ++); //Id gerado seguencial
        Leitor novoLeitor = new Leitor(idGerado, nome, email, telemovel);

        //Consulta se o ID do Autor já existe, se sim da mensagem de erro e não prossegue
        if(buscarLeitor(novoLeitor.getId()) != null){
            throw new IllegalStateException("Erro, ID já registado para outro Leitor.");
        }

        //Adiciona o livro na lista
        this.listaLeitores.add(novoLeitor);
        System.out.println("O Leitor " + novoLeitor.getNome() + " com ID: " + idGerado + " foi adicionado com sucesso.");
    }

    //Metodo de editar Leitor
    public void editarLeitor(String id, String novoNome, String novoEmail, String novoTelemovel){
        Leitor leitor = buscarLeitor(id);
        if (leitor == null) {
            throw new IllegalArgumentException("Leitor não encontrado.");
        }
        if (!novoNome.isBlank()) leitor.setNome(novoNome);
        if (!novoEmail.isBlank()) leitor.setEmail(novoEmail);
        if (!novoTelemovel.isBlank()) leitor.setTelemovel(novoTelemovel);

        System.out.println("Leitor atualizado com sucesso.");
    }

    public void listarLeitores() {
        if (listaLeitores.isEmpty()){
            System.out.println("Nenhum leitor registado.");
        }
        else {
            for (Leitor l: listaLeitores){
                System.out.println("ID: " + l.getId() + " | Nome: " + l.getNome() + " | E-mail: " + l.getEmail() + " | Telemovel: " + l.getTelemovel());
            }
        }
    }
}





